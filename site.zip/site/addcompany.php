<script>

// function stringgen(){
//     return(Math.random().toString(36).substring(2, 5) + Math.random().toString(36).substring(2, 5));
// }
</script>
<?php
// Include the database configuration file
session_start();
include '../dbConfig.php';
$statusMsg = '';

// File upload path
$targetDir = "uploads/";
$fileName = basename($_FILES["companylogo"]["name"]);
// print($_FILES["file"]["name"]);
print(isset($_FILES["companylogo"]));
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);


// echo rand(pow(10, $digits-1), pow(10, $digits)-1);

$email=$_POST['companyemail'];
$title=$_POST['companyname'];
$cweb=$_POST['companywebsite'];
$cdes=$_POST['companydescription'];
$pass= "pass";


// echo $tag1;

// if(isset($_POST["submit"]) ){
    // Allow certain file formats

if(isset($_POST["submit"]) && !empty($_FILES["companylogo"]["name"])){
    // Allow certain file formats
    $allowTypes = array('jpg','png','jpeg','gif');
    if(in_array($fileType, $allowTypes)){
      
        // Upload file to server
        if(move_uploaded_file($_FILES["companylogo"]["tmp_name"], $targetFilePath)){
   
            // Insert image file name into database
            $insert = $db->query("INSERT into employer_account (company_name,description,email,pass,is_active,url,logo,added_on) VALUES ('".$title."','".$cdes."' ,'".$email."','".$pass."','1','".$cweb."','".$fileName."',NOW())");
            if($insert){
                $statusMsg = "The company has been added successfully.";

                echo "<SCRIPT type='text/javascript'> 
                // alert('image uploaded !');
                // window.location.replace(\"http://campuschords.com/index_Admin.php\");
            </SCRIPT>";
            }else{
                $statusMsg = "upload failed, please try again.";
            } 
        }else{
            $statusMsg = "Sorry, there was an error uploading ";
        }
    }
        else{
            $statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF files are allowed to upload.';
        }
        }else{
        $statusMsg = 'Please select a image to upload.';
        }

// Display status message
echo $statusMsg;
?>