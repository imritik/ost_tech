<?php
session_start();
include '../dbConfig.php';

if(isset($_SESSION['emailemp'])){
  }
  else{
    header("location: ../index.php");
  }
  
$studlist= $_SESSION['studlist'];
//get records from database

$arrlength = count($studlist);

$list=array();               
if(sizeof($studlist)){
  // $delimiter = ",";
  // $filename = "members_" . date('Y-m-d') . ".csv";
  
  // $f = fopen('php://memory', 'w');
  
  // $fields = array('ID#', 'Name', 'Address', 'College', 'College_location', 'Contact', 'Email', 'password', 'Company','CTC','Resume','Experience','Registered_on','Modified_on');
  // fputcsv($f, $fields, $delimiter);
$linerow=array('ID#','Name','address','College','Colleg_location','Contact','Email','Password','Company','CTC','Resume','Experience','Registered_on',"modified_on");
array_push($list,$linerow);
  for($x = 0; $x < $arrlength; $x++) {
  
$query = $db->query("SELECT * FROM Student where student_id='$studlist[$x]'");

if($query->num_rows ==1){
    
    
    while($row = $query->fetch_assoc()){
      $resumelinks='http://osttalent.com/jobs/specialty/uploads/'.$studlist[$x].'/'.$row['resume'];
        $lineData = array($row['student_id'], $row['stud_name'], $row['address'], $row['college_name'], $row['college_location'], $row['contact'],  $row['email'],$row['pass'], $row['curr_company'], $row['curr_ctc'], $resumelinks, $row['experience'], $row['updated_on'], $row['modified_on']);
//         fputcsv($f, $lineData, $delimiter);
array_push($list,$lineData);
    }
    
//     fseek($f, 0);
    
//     header('Content-Type: text/csv');
//     header('Content-Disposition: attachment; filename="' . $filename . '";');
    
// fpassthru($f);

}

  }

  // var_dump($list);

$file = fopen('php://memory', 'w');

foreach ($list as $line) {
  fputcsv($file, $line);
}
fseek($file, 0);
// tell the browser it's going to be a csv file
header('Content-Type: text/csv');
// tell the browser we want to save it instead of displaying it
header('Content-Disposition: attachment; filename="truelist.csv";');
// make php send the generated csv lines to the browser
fpassthru($file);

// exit;
}

?>